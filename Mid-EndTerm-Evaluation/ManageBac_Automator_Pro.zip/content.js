chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
    if (request.action === "RUN_AUTOMATION") {
        const tasks = request.tasks;
        const commentPref = request.commentPref; // "1" overwrite, "2" skip original

        const containers = document.querySelectorAll("div.js-student-grade");
        if (containers.length === 0) {
            sendResponse({ success: false, error: "No student containers found. Are you on the class list page?" });
            return true;
        }

        const limit = Math.min(containers.length, tasks.length);
        let processedCount = 0;

        for (let i = 0; i < limit; i++) {
            let container = containers[i];
            let task = tasks[i];

            // --- 1. PASTE COMMENT ---
            let skipIfNotEmpty = (commentPref === "2");
            let hasContent = false;

            let textareas = container.querySelectorAll('textarea');
            for (let t of textareas) {
                if (t.id.includes('comment') || t.name.includes('comment')) {
                    if (t.value.trim() !== '') hasContent = true;
                }
            }
            if (window.CKEDITOR) {
                for (let instance in window.CKEDITOR.instances) {
                    let editorNode = document.getElementById('cke_' + instance);
                    if (editorNode && container.contains(editorNode)) {
                        let data = window.CKEDITOR.instances[instance].getData().replace(/<[^>]*>/g, '').trim();
                        if (data !== '') hasContent = true;
                    }
                }
            }
            let editables = container.querySelectorAll('[contenteditable="true"]');
            for (let ed of editables) {
                if (ed.innerText.trim() !== '') hasContent = true;
            }

            if (!(skipIfNotEmpty && hasContent)) {
                // Do the pasting logic
                for (let t of textareas) {
                    if (t.id.includes('comment') || t.name.includes('comment')) {
                        t.value = task.comment;
                        t.dispatchEvent(new Event('change', { bubbles: true }));
                        t.dispatchEvent(new Event('input', { bubbles: true }));
                    }
                }
                if (window.CKEDITOR) {
                    for (let instance in window.CKEDITOR.instances) {
                        let editorNode = document.getElementById('cke_' + instance);
                        if (editorNode && container.contains(editorNode)) {
                            window.CKEDITOR.instances[instance].setData(task.comment);
                        }
                    }
                }
                for (let ed of editables) {
                    ed.innerHTML = task.comment;
                    ed.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }

            // --- 2. SET GRADES ---
            for (let crit in task.grades) {
                let targetScore = task.grades[crit];
                let buttons = container.querySelectorAll('[data-final-grade]');
                let found = false;

                for (let btn of buttons) {
                    try {
                        let attr = btn.getAttribute('data-final-grade');
                        if (!attr) continue;
                        let data = JSON.parse(attr);

                        if (data.criterion && data.criterion.toLowerCase() === crit.toLowerCase()) {
                            let isMatch = false;
                            if (targetScore === null) {
                                if (data.score === null || data.score === undefined || data.score === "") isMatch = true;
                            } else {
                                if (data.score !== null && data.score !== undefined && data.score == targetScore) isMatch = true;
                            }

                            if (isMatch) {
                                btn.click();
                                btn.dispatchEvent(new MouseEvent('mousedown', { bubbles: true }));
                                btn.dispatchEvent(new MouseEvent('mouseup', { bubbles: true }));
                                found = true;
                                break;
                            }
                        }
                    } catch (e) { }
                }

                // If N/A and not found by JSON, fallback to clicking N/A text
                if (targetScore === null && !found) {
                    let allElems = container.querySelectorAll('div, span, a, button');
                    for (let el of allElems) {
                        if (el.innerText && el.innerText.trim().toUpperCase() === 'N/A') {
                            let parentData = el.closest('[data-final-grade]');
                            if (parentData) {
                                let d = JSON.parse(parentData.getAttribute('data-final-grade'));
                                if (d.criterion.toLowerCase() === crit.toLowerCase()) {
                                    el.click();
                                    break;
                                }
                            } else {
                                el.click();
                            }
                        }
                    }
                }
            }

            processedCount++;
        }

        sendResponse({ success: true, count: processedCount });
        return true;
    }
});
