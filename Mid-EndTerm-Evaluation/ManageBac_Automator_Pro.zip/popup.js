let workbook = null;
let _headers = [];
let _sheetData = [];
let _parsedComments = [];

document.addEventListener('DOMContentLoaded', () => {
  const txtUpload = document.getElementById('txtUpload');
  const excelUpload = document.getElementById('excelUpload');
  const txtUploadLbl = document.getElementById('txtUploadLbl');
  const excelUploadLbl = document.getElementById('excelUploadLbl');
  const sheetSelect = document.getElementById('sheetSelect');
  const step2 = document.getElementById('step2');
  const runBtn = document.getElementById('runBtn');
  const statusMsg = document.getElementById('statusMessage');

  // Handle TXT Upload
  txtUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    txtUploadLbl.textContent = file.name;
    txtUploadLbl.style.color = 'var(--text-main)';

    const reader = new FileReader();
    reader.onload = (evt) => {
      _parsedComments = parseComments(evt.target.result);
      if(_parsedComments.length > 0) {
        setStatus(`Loaded ${_parsedComments.length} comments.`, 'success');
      } else {
        setStatus(`Error: No comments matched the format.`, 'error');
      }
      checkReady();
    };
    reader.readAsText(file);
  });

  // Handle Excel Upload
  excelUpload.addEventListener('change', (e) => {
    const file = e.target.files[0];
    if (!file) return;
    excelUploadLbl.textContent = file.name;
    excelUploadLbl.style.color = 'var(--text-main)';

    const reader = new FileReader();
    reader.onload = (evt) => {
      const data = new Uint8Array(evt.target.result);
      try {
        workbook = XLSX.read(data, {type: 'array'});
        populateSheetDropdown();
        step2.classList.remove('hidden');
        setStatus(`Excel loaded successfully.`, 'success');
      } catch (err) {
        setStatus(`Error reading Excel: ${err.message}`, 'error');
      }
    };
    reader.readAsArrayBuffer(file);
  });

  // Handle Sheet Selection
  sheetSelect.addEventListener('change', () => {
    loadSheetData(sheetSelect.value);
  });

  function populateSheetDropdown() {
    sheetSelect.innerHTML = '';
    workbook.SheetNames.forEach(name => {
      const opt = document.createElement('option');
      opt.value = name;
      opt.textContent = name;
      sheetSelect.appendChild(opt);
    });
    if(workbook.SheetNames.length > 0) {
      loadSheetData(workbook.SheetNames[0]);
    }
  }

  function loadSheetData(sheetName) {
    const sheet = workbook.Sheets[sheetName];
    const jsonData = XLSX.utils.sheet_to_json(sheet, {header: 1, defval: ""});
    if(jsonData.length < 1) {
      setStatus("Sheet is empty.", "error"); return;
    }
    _headers = jsonData[0].map(h => h.toString().trim());
    
    // Create an array of objects
    _sheetData = [];
    for(let i = 1; i < jsonData.length; i++) {
      let rowObj = {};
      for(let j=0; j<_headers.length; j++) {
        rowObj[_headers[j]] = jsonData[i][j];
      }
      
      let fullNameChk = rowObj['NOMBRE'] !== undefined ? rowObj['NOMBRE'] : rowObj[_headers[0]];
      if (fullNameChk !== undefined && fullNameChk !== null && String(fullNameChk).trim() !== '') {
        _sheetData.push(rowObj);
      }
    }
    
    populateCriteriaDropdowns();
    checkReady();
  }

  function populateCriteriaDropdowns() {
    ['critA', 'critB', 'critC', 'critD'].forEach(id => {
      const select = document.getElementById(id);
      select.innerHTML = '<option value="">-- Skip --</option>';
      _headers.forEach(header => {
        if(header && header.toUpperCase() !== 'NOMBRE' && header.toUpperCase() !== 'NAME') {
          const opt = document.createElement('option');
          opt.value = header;
          opt.textContent = header;
          select.appendChild(opt);
        }
      });
    });
  }

  function checkReady() {
    if (_parsedComments.length > 0 && _sheetData.length > 0) {
      runBtn.disabled = false;
    } else {
      runBtn.disabled = true;
    }
  }

  function setStatus(msg, type) {
    statusMsg.textContent = msg;
    statusMsg.className = 'status ' + type;
  }

  // --- Regex Parser ---
  function normalizeText(str) {
    if(!str) return "";
    return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase().trim();
  }

  function parseComments(text) {
    const content = '\n' + text;
    const blocks = content.split(/\n\d+\.\s*([^:]+):/);
    let stComments = [];
    for(let i = 1; i < blocks.length; i += 2) {
      if (i + 1 < blocks.length) {
        stComments.push({
          name: blocks[i].trim(),
          normalized_name: normalizeText(blocks[i].trim()),
          comment: blocks[i + 1].trim()
        });
      }
    }
    return stComments;
  }

  // --- Preferences Event Listeners ---
  const commentPrefEl = document.getElementById('commentPref');
  const extraTextRow = document.getElementById('extraTextRow');
  if (commentPrefEl && extraTextRow) {
    commentPrefEl.addEventListener('change', (e) => {
      if (e.target.value === '3') {
        extraTextRow.classList.remove('hidden');
      } else {
        extraTextRow.classList.add('hidden');
      }
    });
  }

  // --- Action ---
  runBtn.addEventListener('click', () => {
    runBtn.disabled = true;
    runBtn.textContent = 'Processing...';
    
    // Retrieve preferences
    const emptyPref = document.getElementById('emptyPref').value;
    const skipPref = document.getElementById('skipPref').value;
    const commentPref = document.getElementById('commentPref').value;
    const extraText = document.getElementById('extraText') ? document.getElementById('extraText').value.trim() : "";
    
    const critMap = {
      'A': document.getElementById('critA').value,
      'B': document.getElementById('critB').value,
      'C': document.getElementById('critC').value,
      'D': document.getElementById('critD').value
    };

    // Build the finalized array of tasks for the selected students
    let finalTasks = [];

    // The logic: Iterate up to min(parsedComments, sheetData) like the Python script.
    const limit = Math.min(_parsedComments.length, _sheetData.length);
    for(let i=0; i < limit; i++) {
      let commentItem = _parsedComments[i];
      let rowItem = _sheetData[i];
      
      let finalCommentText = commentItem.comment;
      if (commentPref === '3' && extraText !== '') {
        finalCommentText = extraText;
      }

      let studentPayload = {
        txt_name: commentItem.name,
        comment: finalCommentText,
        grades: {} 
      };

      // Extract grades based on selected headers
      for(let crit of ['A', 'B', 'C', 'D']) {
        let headerName = critMap[crit];
        if(headerName) { // Not skipped
          let val = rowItem[headerName];
          if(val !== undefined && val !== null && String(val).trim() !== '') {
            studentPayload.grades[crit] = parseInt(val, 10);
          } else if (emptyPref === "2") {
            studentPayload.grades[crit] = null; // Mark N/A
          }
        } else if (skipPref === "2") {
          studentPayload.grades[crit] = null; // Mark N/A
        }
      }
      finalTasks.push(studentPayload);
    }

    // Connect to the active Chrome tab
    chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
      if(!tabs[0].url.includes('managebac.com')) {
        setStatus("Target tab must be ManageBac class list.", "error");
        runBtn.textContent = 'Run Automation';
        runBtn.disabled = false;
        return;
      }

      chrome.scripting.executeScript({
        target: {tabId: tabs[0].id},
        files: ['content.js']
      }, () => {
        // Send our data to content.js
        let jsCommentPref = commentPref;
        if (commentPref === '3') jsCommentPref = '2'; // Paste ONLY if empty

        chrome.tabs.sendMessage(tabs[0].id, {
          action: "RUN_AUTOMATION", 
          tasks: finalTasks,
          commentPref: jsCommentPref
        }, function(response) {
            if (response && response.success) {
                setStatus(`Processed ${response.count} students!`, "success");
            } else {
                setStatus("Unable to communicate with ManageBac page.", "error");
            }
            runBtn.textContent = 'Run Automation';
            runBtn.disabled = false;
        });
      });
    });
  });

});
